import java.util.Scanner;

public class Game 
{
    Scanner sc = new Scanner(System.in);
    Player[] players;

    int maxPieces;
    int maxRemovable;

    public Game(Player[] p)
    {
        this.players = p;
        maxPieces = (int)(Math.random() * 41) + 10;
    }

    // ----- ACCESSORS ----- //

    public int getMaxPieces()
    {
        return maxPieces;
    }

    public int getMaxRemovable()
    {
        return maxRemovable;
    }

    // ----- MUTATORS ----- //

    public void roboTurn()
    {
        
    }

    public void playerTurn()
    {

    }


}
