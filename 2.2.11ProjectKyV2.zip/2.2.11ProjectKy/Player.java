import java.util.Scanner;

public class Player
{
    private static Scanner sc = new Scanner(System.in);
    private String name = "";
    private int numWins = 0;

    public Player()
    {
        System.out.println("Please input player name:");
        this.name = sc.nextLine();
        System.out.println("Welcome, " + name);
    }

    public String getName()
    {
        return name;
    }

    public String toString()
    {
        String info = "Player: " + name + "\nNumber of wins: " + numWins;
        return info;
    }

    public void addWin(int win)
    {
        numWins += win;
    }
}