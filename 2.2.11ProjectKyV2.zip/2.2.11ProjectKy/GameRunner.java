import java.util.ArrayList;
import java.util.Scanner;

public class GameRunner
{
    public static ArrayList<Player> playerRecords = new ArrayList<>();
    public static boolean playing;
    
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        play();
    }

    public static void play()
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Singleplayer or Multiplayer?");

        // ----- CODE THAT LETS YOU CHOOSE BETWEEN: DEFAULT IS SINGLEPLAYER WITH ROBOT
        
        /* if (!playerRecords.isEmpty())
        {
            System.out.println("Would you like to use old player data? Yes [1] ; No [2]");
            int input = sc.nextInt();

            if (input == 1)
            {
                System.out.println()
            }
        } */

        Player player1 = new Player();

        Player[] players = new Player[2];
        players[0] = player1;

        for (int i = 0; i < players.length - 1; i++)
        {
            if (players[i] != null)
            {
                playerRecords.add(players[i]);
            }
        }

        Game g = new Game(players);

        int currentPlayer = (int)(Math.random() * 2);
        while (g.currPieces > 1)
        {
            for (int i = 0; i < g.currPieces; i++)
            {
                System.out.print("🪨 ");
            }
            System.out.println("\nThere are " + g.currPieces + " pieces on the board.");
            if (players[currentPlayer] != null)
            {
                g.playerTurn();
            }
            else
            {
                g.roboTurn();
            }

            if ((currentPlayer + 1) == players.length)
            {
                currentPlayer = 0;
            }
            else
            {
                currentPlayer++;
            }
        }

        int winInt;
        if ((currentPlayer + 1) == players.length)
        {
            winInt = 0;
        }
        else
        {
            winInt = 1;
        }

        System.out.println(players[currentPlayer].getName() + " loses!");


        System.out.println("Play again? [1] ; Main menu? [2] ; End Program? [3]");
        int choice = sc.nextInt();
        if (choice == 1)
        {
            play();
        }
    }
    
}