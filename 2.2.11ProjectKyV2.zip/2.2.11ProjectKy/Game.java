import java.util.Scanner;

public class Game 
{
    Scanner sc = new Scanner(System.in);
    Player[] players;
    int minRemovable;

    int currPieces;
    int maxRemovable;

    public Game(Player[] p)
    {
        this.players = p;
        currPieces = (int)(Math.random() * 41) + 10;
        minRemovable = 1;
    }

    // ----- ACCESSORS ----- //

    public int getMaxPieces()
    {
        return currPieces;
    }

    public int getMaxRemovable()
    {
        return maxRemovable;
    }

    // ----- MUTATORS ----- //

    public void roboTurn()
    {
        maxRemovable = (int) (currPieces/2);
        int roboRemoves = 1;
        System.out.println("The opponent takes away " + roboRemoves + " pieces.");
        currPieces -= roboRemoves;

        // int roboRemoves = (int) (Math.random() * maxRemovable);
        /* if ((currPieces % 2) == 0) // If current pieces on board is even:
        {
            if (roboRemoves < 1) 
            {
                roboRemoves += 2;
            }

            if (roboRemoves % 2 == 0)
            {
                if (roboRemoves == 0)
                {
                    roboRemoves += 2;
                }
                System.out.println("The opponent takes away " + roboRemoves + " pieces.");
            }
            else if (roboRemoves % 2 != 0)
            {
                if (roboRemoves == 1)
                {
                    roboRemoves++;
                }
                else                    
                {
                    roboRemoves -= 1;
                }
                System.out.println("The opponent takes away " + roboRemoves + " pieces.");
            }

            currPieces -= roboRemoves;
        }
        else
        {

        } */
    }

    public void playerTurn()
    {
        maxRemovable = (int) (currPieces/2);
        System.out.println("The minimum amount of pieces you can remove is " + minRemovable);
        System.out.println("The max amount of pieces you can remove is: " + maxRemovable);

        System.out.println("How many pieces would you like to remove?");
        int pRemove = sc.nextInt();

        while (pRemove > maxRemovable || pRemove < minRemovable)
        {
            System.out.println("Please input a number within the range of removal.");
            pRemove = sc.nextInt();
        }

        System.out.println("You remove " + pRemove + " pieces.");
        currPieces -= pRemove;
    }


}
